# Tasks/Activities List:
Your code should contain the following activities/Analysis:

Read the cars dataset.
Exploratory Data Analysis (EDA) - Show the Data quality check, treat the missing values, etc if any.
Transform the categorical data.
Apply the Multiple Linear Regression model
Print the model results
Get the feature importance
Visualize the diagnostic plots


```python
##import libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
import statsmodels.api as sm
import sklearn.metrics as metrics
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import f_regression
from sklearn.feature_selection import mutual_info_regression
```


```python
##Read the dataset

dataset = pd.read_csv ('AnomaData.csv')
```


```python
#understand diffrent columns and data type
dataset.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 18398 entries, 0 to 18397
    Data columns (total 62 columns):
     #   Column  Non-Null Count  Dtype  
    ---  ------  --------------  -----  
     0   time    18398 non-null  object 
     1   y       18398 non-null  int64  
     2   x1      18398 non-null  float64
     3   x2      18398 non-null  float64
     4   x3      18398 non-null  float64
     5   x4      18398 non-null  float64
     6   x5      18398 non-null  float64
     7   x6      18398 non-null  float64
     8   x7      18398 non-null  float64
     9   x8      18398 non-null  float64
     10  x9      18398 non-null  float64
     11  x10     18398 non-null  float64
     12  x11     18398 non-null  float64
     13  x12     18398 non-null  float64
     14  x13     18398 non-null  float64
     15  x14     18398 non-null  float64
     16  x15     18398 non-null  float64
     17  x16     18398 non-null  float64
     18  x17     18398 non-null  float64
     19  x18     18398 non-null  float64
     20  x19     18398 non-null  float64
     21  x20     18398 non-null  float64
     22  x21     18398 non-null  float64
     23  x22     18398 non-null  float64
     24  x23     18398 non-null  float64
     25  x24     18398 non-null  float64
     26  x25     18398 non-null  float64
     27  x26     18398 non-null  float64
     28  x27     18398 non-null  float64
     29  x28     18398 non-null  int64  
     30  x29     18398 non-null  float64
     31  x30     18398 non-null  float64
     32  x31     18398 non-null  float64
     33  x32     18398 non-null  float64
     34  x33     18398 non-null  float64
     35  x34     18398 non-null  float64
     36  x35     18398 non-null  float64
     37  x36     18398 non-null  float64
     38  x37     18398 non-null  float64
     39  x38     18398 non-null  float64
     40  x39     18398 non-null  float64
     41  x40     18398 non-null  float64
     42  x41     18398 non-null  float64
     43  x42     18398 non-null  float64
     44  x43     18398 non-null  float64
     45  x44     18398 non-null  float64
     46  x45     18398 non-null  float64
     47  x46     18398 non-null  float64
     48  x47     18398 non-null  float64
     49  x48     18398 non-null  float64
     50  x49     18398 non-null  float64
     51  x50     18398 non-null  float64
     52  x51     18398 non-null  float64
     53  x52     18398 non-null  float64
     54  x54     18398 non-null  float64
     55  x55     18398 non-null  float64
     56  x56     18398 non-null  float64
     57  x57     18398 non-null  float64
     58  x58     18398 non-null  float64
     59  x59     18398 non-null  float64
     60  x60     18398 non-null  float64
     61  y.1     18398 non-null  int64  
    dtypes: float64(58), int64(3), object(1)
    memory usage: 8.7+ MB
    


```python
#undersand total number of records in dataset
len(dataset)
```




    18398




```python
#undersand total number of records in dataset
dataset.columns
```




    Index(['time', 'y', 'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7', 'x8', 'x9',
           'x10', 'x11', 'x12', 'x13', 'x14', 'x15', 'x16', 'x17', 'x18', 'x19',
           'x20', 'x21', 'x22', 'x23', 'x24', 'x25', 'x26', 'x27', 'x28', 'x29',
           'x30', 'x31', 'x32', 'x33', 'x34', 'x35', 'x36', 'x37', 'x38', 'x39',
           'x40', 'x41', 'x42', 'x43', 'x44', 'x45', 'x46', 'x47', 'x48', 'x49',
           'x50', 'x51', 'x52', 'x54', 'x55', 'x56', 'x57', 'x58', 'x59', 'x60',
           'y.1'],
          dtype='object')




```python
dataset = dataset.drop(['y.1'], axis=1)
```


```python
dataset.columns
```




    Index(['time', 'y', 'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7', 'x8', 'x9',
           'x10', 'x11', 'x12', 'x13', 'x14', 'x15', 'x16', 'x17', 'x18', 'x19',
           'x20', 'x21', 'x22', 'x23', 'x24', 'x25', 'x26', 'x27', 'x28', 'x29',
           'x30', 'x31', 'x32', 'x33', 'x34', 'x35', 'x36', 'x37', 'x38', 'x39',
           'x40', 'x41', 'x42', 'x43', 'x44', 'x45', 'x46', 'x47', 'x48', 'x49',
           'x50', 'x51', 'x52', 'x54', 'x55', 'x56', 'x57', 'x58', 'x59', 'x60'],
          dtype='object')




```python
#undersand total number of columns present in dataset
len(dataset.columns)
```




    61




```python
dataset
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>time</th>
      <th>y</th>
      <th>x1</th>
      <th>x2</th>
      <th>x3</th>
      <th>x4</th>
      <th>x5</th>
      <th>x6</th>
      <th>x7</th>
      <th>x8</th>
      <th>...</th>
      <th>x50</th>
      <th>x51</th>
      <th>x52</th>
      <th>x54</th>
      <th>x55</th>
      <th>x56</th>
      <th>x57</th>
      <th>x58</th>
      <th>x59</th>
      <th>x60</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>05-01-1999 00:00</td>
      <td>0</td>
      <td>0.376665</td>
      <td>-4.596435</td>
      <td>-4.095756</td>
      <td>13.497687</td>
      <td>-0.118830</td>
      <td>-20.669883</td>
      <td>0.000732</td>
      <td>-0.061114</td>
      <td>...</td>
      <td>11.295155</td>
      <td>29.984624</td>
      <td>10.091721</td>
      <td>-4.936434</td>
      <td>-24.590146</td>
      <td>18.515436</td>
      <td>3.473400</td>
      <td>0.033444</td>
      <td>0.953219</td>
      <td>0.006076</td>
    </tr>
    <tr>
      <th>1</th>
      <td>05-01-1999 00:02</td>
      <td>0</td>
      <td>0.475720</td>
      <td>-4.542502</td>
      <td>-4.018359</td>
      <td>16.230659</td>
      <td>-0.128733</td>
      <td>-18.758079</td>
      <td>0.000732</td>
      <td>-0.061114</td>
      <td>...</td>
      <td>11.290761</td>
      <td>29.984624</td>
      <td>10.095871</td>
      <td>-4.937179</td>
      <td>-32.413266</td>
      <td>22.760065</td>
      <td>2.682933</td>
      <td>0.033536</td>
      <td>1.090502</td>
      <td>0.006083</td>
    </tr>
    <tr>
      <th>2</th>
      <td>05-01-1999 00:04</td>
      <td>0</td>
      <td>0.363848</td>
      <td>-4.681394</td>
      <td>-4.353147</td>
      <td>14.127997</td>
      <td>-0.138636</td>
      <td>-17.836632</td>
      <td>0.010803</td>
      <td>-0.061114</td>
      <td>...</td>
      <td>11.286366</td>
      <td>29.984624</td>
      <td>10.100265</td>
      <td>-4.937924</td>
      <td>-34.183774</td>
      <td>27.004663</td>
      <td>3.537487</td>
      <td>0.033629</td>
      <td>1.840540</td>
      <td>0.006090</td>
    </tr>
    <tr>
      <th>3</th>
      <td>05-01-1999 00:06</td>
      <td>0</td>
      <td>0.301590</td>
      <td>-4.758934</td>
      <td>-4.023612</td>
      <td>13.161566</td>
      <td>-0.148142</td>
      <td>-18.517601</td>
      <td>0.002075</td>
      <td>-0.061114</td>
      <td>...</td>
      <td>11.281972</td>
      <td>29.984624</td>
      <td>10.104660</td>
      <td>-4.938669</td>
      <td>-35.954281</td>
      <td>21.672449</td>
      <td>3.986095</td>
      <td>0.033721</td>
      <td>2.554880</td>
      <td>0.006097</td>
    </tr>
    <tr>
      <th>4</th>
      <td>05-01-1999 00:08</td>
      <td>0</td>
      <td>0.265578</td>
      <td>-4.749928</td>
      <td>-4.333150</td>
      <td>15.267340</td>
      <td>-0.155314</td>
      <td>-17.505913</td>
      <td>0.000732</td>
      <td>-0.061114</td>
      <td>...</td>
      <td>11.277577</td>
      <td>29.984624</td>
      <td>10.109054</td>
      <td>-4.939414</td>
      <td>-37.724789</td>
      <td>21.907251</td>
      <td>3.601573</td>
      <td>0.033777</td>
      <td>1.410494</td>
      <td>0.006105</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>18393</th>
      <td>5-28-99 23:58</td>
      <td>0</td>
      <td>-0.877441</td>
      <td>0.786430</td>
      <td>0.406426</td>
      <td>135.301215</td>
      <td>0.112295</td>
      <td>26.300392</td>
      <td>-0.159185</td>
      <td>0.058823</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.682413</td>
      <td>6.944644</td>
      <td>-37.795661</td>
      <td>-0.860218</td>
      <td>0.010220</td>
      <td>0.895685</td>
      <td>-0.011242</td>
    </tr>
    <tr>
      <th>18394</th>
      <td>5-29-99 0:00</td>
      <td>0</td>
      <td>-0.843988</td>
      <td>0.633086</td>
      <td>0.561918</td>
      <td>133.228949</td>
      <td>0.141332</td>
      <td>25.678597</td>
      <td>-0.159185</td>
      <td>0.058823</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.683338</td>
      <td>0.507755</td>
      <td>-39.357199</td>
      <td>-0.915698</td>
      <td>0.010620</td>
      <td>0.175348</td>
      <td>-0.011235</td>
    </tr>
    <tr>
      <th>18395</th>
      <td>5-29-99 0:02</td>
      <td>0</td>
      <td>-0.826547</td>
      <td>0.450126</td>
      <td>0.334582</td>
      <td>134.977973</td>
      <td>0.170370</td>
      <td>25.056801</td>
      <td>-0.159185</td>
      <td>0.048752</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.684263</td>
      <td>2.809146</td>
      <td>-39.357199</td>
      <td>-1.409596</td>
      <td>0.013323</td>
      <td>0.621020</td>
      <td>-0.011228</td>
    </tr>
    <tr>
      <th>18396</th>
      <td>5-29-99 0:04</td>
      <td>0</td>
      <td>-0.822843</td>
      <td>0.419383</td>
      <td>0.387263</td>
      <td>135.658942</td>
      <td>0.199422</td>
      <td>24.435005</td>
      <td>-0.159185</td>
      <td>0.048752</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.685189</td>
      <td>2.164859</td>
      <td>-39.357199</td>
      <td>-0.860218</td>
      <td>0.012888</td>
      <td>1.390902</td>
      <td>-0.011221</td>
    </tr>
    <tr>
      <th>18397</th>
      <td>5-29-99 0:06</td>
      <td>0</td>
      <td>-0.840981</td>
      <td>0.582710</td>
      <td>0.593416</td>
      <td>136.339880</td>
      <td>0.228460</td>
      <td>24.712960</td>
      <td>-0.159185</td>
      <td>0.048752</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.686114</td>
      <td>1.416690</td>
      <td>-39.357199</td>
      <td>-0.732044</td>
      <td>0.012453</td>
      <td>0.418993</td>
      <td>-0.011214</td>
    </tr>
  </tbody>
</table>
<p>18398 rows × 61 columns</p>
</div>



# Exploratory Data Analysis (EDA) - Show the Data quality check, treat the missing values, etc if any.


```python
plt.figure(figsize=(15,5))
sns.lmplot(data=dataset,y='y',x='x1')
plt.show()
```

    C:\ProgramData\anaconda3\Lib\site-packages\seaborn\axisgrid.py:118: UserWarning: The figure layout has changed to tight
      self._figure.tight_layout(*args, **kwargs)
    


    <Figure size 1500x500 with 0 Axes>



    
![png](output_11_2.png)
    



```python
plt.figure(figsize=(15,5))
sns.lmplot(data=dataset,y='y',x='x2')
plt.show()
```

    C:\ProgramData\anaconda3\Lib\site-packages\seaborn\axisgrid.py:118: UserWarning: The figure layout has changed to tight
      self._figure.tight_layout(*args, **kwargs)
    


    <Figure size 1500x500 with 0 Axes>



    
![png](output_12_2.png)
    



```python
plt.figure(figsize=(15,5))
sns.lmplot(data=dataset,y='y',x='x3')
plt.show()
```

    C:\ProgramData\anaconda3\Lib\site-packages\seaborn\axisgrid.py:118: UserWarning: The figure layout has changed to tight
      self._figure.tight_layout(*args, **kwargs)
    


    <Figure size 1500x500 with 0 Axes>



    
![png](output_13_2.png)
    


not much information can be visualized through python plots as predictor values are large in numbers

## Missing value treatment


```python
dataset.isnull().sum()/len(dataset)*100
```




    time    0.0
    y       0.0
    x1      0.0
    x2      0.0
    x3      0.0
           ... 
    x56     0.0
    x57     0.0
    x58     0.0
    x59     0.0
    x60     0.0
    Length: 61, dtype: float64




```python
dataset
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>time</th>
      <th>y</th>
      <th>x1</th>
      <th>x2</th>
      <th>x3</th>
      <th>x4</th>
      <th>x5</th>
      <th>x6</th>
      <th>x7</th>
      <th>x8</th>
      <th>...</th>
      <th>x50</th>
      <th>x51</th>
      <th>x52</th>
      <th>x54</th>
      <th>x55</th>
      <th>x56</th>
      <th>x57</th>
      <th>x58</th>
      <th>x59</th>
      <th>x60</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>05-01-1999 00:00</td>
      <td>0</td>
      <td>0.376665</td>
      <td>-4.596435</td>
      <td>-4.095756</td>
      <td>13.497687</td>
      <td>-0.118830</td>
      <td>-20.669883</td>
      <td>0.000732</td>
      <td>-0.061114</td>
      <td>...</td>
      <td>11.295155</td>
      <td>29.984624</td>
      <td>10.091721</td>
      <td>-4.936434</td>
      <td>-24.590146</td>
      <td>18.515436</td>
      <td>3.473400</td>
      <td>0.033444</td>
      <td>0.953219</td>
      <td>0.006076</td>
    </tr>
    <tr>
      <th>1</th>
      <td>05-01-1999 00:02</td>
      <td>0</td>
      <td>0.475720</td>
      <td>-4.542502</td>
      <td>-4.018359</td>
      <td>16.230659</td>
      <td>-0.128733</td>
      <td>-18.758079</td>
      <td>0.000732</td>
      <td>-0.061114</td>
      <td>...</td>
      <td>11.290761</td>
      <td>29.984624</td>
      <td>10.095871</td>
      <td>-4.937179</td>
      <td>-32.413266</td>
      <td>22.760065</td>
      <td>2.682933</td>
      <td>0.033536</td>
      <td>1.090502</td>
      <td>0.006083</td>
    </tr>
    <tr>
      <th>2</th>
      <td>05-01-1999 00:04</td>
      <td>0</td>
      <td>0.363848</td>
      <td>-4.681394</td>
      <td>-4.353147</td>
      <td>14.127997</td>
      <td>-0.138636</td>
      <td>-17.836632</td>
      <td>0.010803</td>
      <td>-0.061114</td>
      <td>...</td>
      <td>11.286366</td>
      <td>29.984624</td>
      <td>10.100265</td>
      <td>-4.937924</td>
      <td>-34.183774</td>
      <td>27.004663</td>
      <td>3.537487</td>
      <td>0.033629</td>
      <td>1.840540</td>
      <td>0.006090</td>
    </tr>
    <tr>
      <th>3</th>
      <td>05-01-1999 00:06</td>
      <td>0</td>
      <td>0.301590</td>
      <td>-4.758934</td>
      <td>-4.023612</td>
      <td>13.161566</td>
      <td>-0.148142</td>
      <td>-18.517601</td>
      <td>0.002075</td>
      <td>-0.061114</td>
      <td>...</td>
      <td>11.281972</td>
      <td>29.984624</td>
      <td>10.104660</td>
      <td>-4.938669</td>
      <td>-35.954281</td>
      <td>21.672449</td>
      <td>3.986095</td>
      <td>0.033721</td>
      <td>2.554880</td>
      <td>0.006097</td>
    </tr>
    <tr>
      <th>4</th>
      <td>05-01-1999 00:08</td>
      <td>0</td>
      <td>0.265578</td>
      <td>-4.749928</td>
      <td>-4.333150</td>
      <td>15.267340</td>
      <td>-0.155314</td>
      <td>-17.505913</td>
      <td>0.000732</td>
      <td>-0.061114</td>
      <td>...</td>
      <td>11.277577</td>
      <td>29.984624</td>
      <td>10.109054</td>
      <td>-4.939414</td>
      <td>-37.724789</td>
      <td>21.907251</td>
      <td>3.601573</td>
      <td>0.033777</td>
      <td>1.410494</td>
      <td>0.006105</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>18393</th>
      <td>5-28-99 23:58</td>
      <td>0</td>
      <td>-0.877441</td>
      <td>0.786430</td>
      <td>0.406426</td>
      <td>135.301215</td>
      <td>0.112295</td>
      <td>26.300392</td>
      <td>-0.159185</td>
      <td>0.058823</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.682413</td>
      <td>6.944644</td>
      <td>-37.795661</td>
      <td>-0.860218</td>
      <td>0.010220</td>
      <td>0.895685</td>
      <td>-0.011242</td>
    </tr>
    <tr>
      <th>18394</th>
      <td>5-29-99 0:00</td>
      <td>0</td>
      <td>-0.843988</td>
      <td>0.633086</td>
      <td>0.561918</td>
      <td>133.228949</td>
      <td>0.141332</td>
      <td>25.678597</td>
      <td>-0.159185</td>
      <td>0.058823</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.683338</td>
      <td>0.507755</td>
      <td>-39.357199</td>
      <td>-0.915698</td>
      <td>0.010620</td>
      <td>0.175348</td>
      <td>-0.011235</td>
    </tr>
    <tr>
      <th>18395</th>
      <td>5-29-99 0:02</td>
      <td>0</td>
      <td>-0.826547</td>
      <td>0.450126</td>
      <td>0.334582</td>
      <td>134.977973</td>
      <td>0.170370</td>
      <td>25.056801</td>
      <td>-0.159185</td>
      <td>0.048752</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.684263</td>
      <td>2.809146</td>
      <td>-39.357199</td>
      <td>-1.409596</td>
      <td>0.013323</td>
      <td>0.621020</td>
      <td>-0.011228</td>
    </tr>
    <tr>
      <th>18396</th>
      <td>5-29-99 0:04</td>
      <td>0</td>
      <td>-0.822843</td>
      <td>0.419383</td>
      <td>0.387263</td>
      <td>135.658942</td>
      <td>0.199422</td>
      <td>24.435005</td>
      <td>-0.159185</td>
      <td>0.048752</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.685189</td>
      <td>2.164859</td>
      <td>-39.357199</td>
      <td>-0.860218</td>
      <td>0.012888</td>
      <td>1.390902</td>
      <td>-0.011221</td>
    </tr>
    <tr>
      <th>18397</th>
      <td>5-29-99 0:06</td>
      <td>0</td>
      <td>-0.840981</td>
      <td>0.582710</td>
      <td>0.593416</td>
      <td>136.339880</td>
      <td>0.228460</td>
      <td>24.712960</td>
      <td>-0.159185</td>
      <td>0.048752</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.686114</td>
      <td>1.416690</td>
      <td>-39.357199</td>
      <td>-0.732044</td>
      <td>0.012453</td>
      <td>0.418993</td>
      <td>-0.011214</td>
    </tr>
  </tbody>
</table>
<p>18398 rows × 61 columns</p>
</div>




```python
dataset.columns
```




    Index(['time', 'y', 'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7', 'x8', 'x9',
           'x10', 'x11', 'x12', 'x13', 'x14', 'x15', 'x16', 'x17', 'x18', 'x19',
           'x20', 'x21', 'x22', 'x23', 'x24', 'x25', 'x26', 'x27', 'x28', 'x29',
           'x30', 'x31', 'x32', 'x33', 'x34', 'x35', 'x36', 'x37', 'x38', 'x39',
           'x40', 'x41', 'x42', 'x43', 'x44', 'x45', 'x46', 'x47', 'x48', 'x49',
           'x50', 'x51', 'x52', 'x54', 'x55', 'x56', 'x57', 'x58', 'x59', 'x60'],
          dtype='object')



# Assigning values to x and y


```python
y_col= dataset['y']
y = y_col
```


```python
x = dataset.drop(['time','y'], axis=1)
```


```python
y
```




    0        0
    1        0
    2        0
    3        0
    4        0
            ..
    18393    0
    18394    0
    18395    0
    18396    0
    18397    0
    Name: y, Length: 18398, dtype: int64




```python
x
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>x1</th>
      <th>x2</th>
      <th>x3</th>
      <th>x4</th>
      <th>x5</th>
      <th>x6</th>
      <th>x7</th>
      <th>x8</th>
      <th>x9</th>
      <th>x10</th>
      <th>...</th>
      <th>x50</th>
      <th>x51</th>
      <th>x52</th>
      <th>x54</th>
      <th>x55</th>
      <th>x56</th>
      <th>x57</th>
      <th>x58</th>
      <th>x59</th>
      <th>x60</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.376665</td>
      <td>-4.596435</td>
      <td>-4.095756</td>
      <td>13.497687</td>
      <td>-0.118830</td>
      <td>-20.669883</td>
      <td>0.000732</td>
      <td>-0.061114</td>
      <td>-0.059966</td>
      <td>-0.038189</td>
      <td>...</td>
      <td>11.295155</td>
      <td>29.984624</td>
      <td>10.091721</td>
      <td>-4.936434</td>
      <td>-24.590146</td>
      <td>18.515436</td>
      <td>3.473400</td>
      <td>0.033444</td>
      <td>0.953219</td>
      <td>0.006076</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.475720</td>
      <td>-4.542502</td>
      <td>-4.018359</td>
      <td>16.230659</td>
      <td>-0.128733</td>
      <td>-18.758079</td>
      <td>0.000732</td>
      <td>-0.061114</td>
      <td>-0.059966</td>
      <td>-0.038189</td>
      <td>...</td>
      <td>11.290761</td>
      <td>29.984624</td>
      <td>10.095871</td>
      <td>-4.937179</td>
      <td>-32.413266</td>
      <td>22.760065</td>
      <td>2.682933</td>
      <td>0.033536</td>
      <td>1.090502</td>
      <td>0.006083</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.363848</td>
      <td>-4.681394</td>
      <td>-4.353147</td>
      <td>14.127997</td>
      <td>-0.138636</td>
      <td>-17.836632</td>
      <td>0.010803</td>
      <td>-0.061114</td>
      <td>-0.030057</td>
      <td>-0.018352</td>
      <td>...</td>
      <td>11.286366</td>
      <td>29.984624</td>
      <td>10.100265</td>
      <td>-4.937924</td>
      <td>-34.183774</td>
      <td>27.004663</td>
      <td>3.537487</td>
      <td>0.033629</td>
      <td>1.840540</td>
      <td>0.006090</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.301590</td>
      <td>-4.758934</td>
      <td>-4.023612</td>
      <td>13.161566</td>
      <td>-0.148142</td>
      <td>-18.517601</td>
      <td>0.002075</td>
      <td>-0.061114</td>
      <td>-0.019986</td>
      <td>-0.008280</td>
      <td>...</td>
      <td>11.281972</td>
      <td>29.984624</td>
      <td>10.104660</td>
      <td>-4.938669</td>
      <td>-35.954281</td>
      <td>21.672449</td>
      <td>3.986095</td>
      <td>0.033721</td>
      <td>2.554880</td>
      <td>0.006097</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.265578</td>
      <td>-4.749928</td>
      <td>-4.333150</td>
      <td>15.267340</td>
      <td>-0.155314</td>
      <td>-17.505913</td>
      <td>0.000732</td>
      <td>-0.061114</td>
      <td>-0.030057</td>
      <td>-0.008280</td>
      <td>...</td>
      <td>11.277577</td>
      <td>29.984624</td>
      <td>10.109054</td>
      <td>-4.939414</td>
      <td>-37.724789</td>
      <td>21.907251</td>
      <td>3.601573</td>
      <td>0.033777</td>
      <td>1.410494</td>
      <td>0.006105</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>18393</th>
      <td>-0.877441</td>
      <td>0.786430</td>
      <td>0.406426</td>
      <td>135.301215</td>
      <td>0.112295</td>
      <td>26.300392</td>
      <td>-0.159185</td>
      <td>0.058823</td>
      <td>-0.080108</td>
      <td>-0.038189</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.682413</td>
      <td>6.944644</td>
      <td>-37.795661</td>
      <td>-0.860218</td>
      <td>0.010220</td>
      <td>0.895685</td>
      <td>-0.011242</td>
    </tr>
    <tr>
      <th>18394</th>
      <td>-0.843988</td>
      <td>0.633086</td>
      <td>0.561918</td>
      <td>133.228949</td>
      <td>0.141332</td>
      <td>25.678597</td>
      <td>-0.159185</td>
      <td>0.058823</td>
      <td>-0.080108</td>
      <td>-0.038189</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.683338</td>
      <td>0.507755</td>
      <td>-39.357199</td>
      <td>-0.915698</td>
      <td>0.010620</td>
      <td>0.175348</td>
      <td>-0.011235</td>
    </tr>
    <tr>
      <th>18395</th>
      <td>-0.826547</td>
      <td>0.450126</td>
      <td>0.334582</td>
      <td>134.977973</td>
      <td>0.170370</td>
      <td>25.056801</td>
      <td>-0.159185</td>
      <td>0.048752</td>
      <td>-0.080108</td>
      <td>-0.038189</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.684263</td>
      <td>2.809146</td>
      <td>-39.357199</td>
      <td>-1.409596</td>
      <td>0.013323</td>
      <td>0.621020</td>
      <td>-0.011228</td>
    </tr>
    <tr>
      <th>18396</th>
      <td>-0.822843</td>
      <td>0.419383</td>
      <td>0.387263</td>
      <td>135.658942</td>
      <td>0.199422</td>
      <td>24.435005</td>
      <td>-0.159185</td>
      <td>0.048752</td>
      <td>-0.080108</td>
      <td>-0.038189</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.685189</td>
      <td>2.164859</td>
      <td>-39.357199</td>
      <td>-0.860218</td>
      <td>0.012888</td>
      <td>1.390902</td>
      <td>-0.011221</td>
    </tr>
    <tr>
      <th>18397</th>
      <td>-0.840981</td>
      <td>0.582710</td>
      <td>0.593416</td>
      <td>136.339880</td>
      <td>0.228460</td>
      <td>24.712960</td>
      <td>-0.159185</td>
      <td>0.048752</td>
      <td>-0.070037</td>
      <td>-0.038189</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.686114</td>
      <td>1.416690</td>
      <td>-39.357199</td>
      <td>-0.732044</td>
      <td>0.012453</td>
      <td>0.418993</td>
      <td>-0.011214</td>
    </tr>
  </tbody>
</table>
<p>18398 rows × 59 columns</p>
</div>



# Finding highly correlated values in x (predictor variable)


```python
cor = x.corr()
plt.figure(figsize=(12,10))
sns.heatmap(cor, cmap=plt.cm.CMRmap_r,annot=True)
plt.show()  
```


    
![png](output_25_0.png)
    



```python
#Finding the correlated features
def correlation(dataset, threshold):
    col_corr = set()  
    corr_matrix = dataset.corr()
    for i in range(len(corr_matrix.columns)):
        for j in range(i):
            if abs(corr_matrix.iloc[i, j]) > threshold: colname = corr_matrix.columns[i]                  
    col_corr.add(colname)
    return col_corr     
```


```python
#Getting correlated features
corr_features = correlation(x, 0.7)
corr_features
```




    {'x59'}




```python
#Removing correlated features
x.drop(corr_features,axis=1)
x
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>x1</th>
      <th>x2</th>
      <th>x3</th>
      <th>x4</th>
      <th>x5</th>
      <th>x6</th>
      <th>x7</th>
      <th>x8</th>
      <th>x9</th>
      <th>x10</th>
      <th>...</th>
      <th>x50</th>
      <th>x51</th>
      <th>x52</th>
      <th>x54</th>
      <th>x55</th>
      <th>x56</th>
      <th>x57</th>
      <th>x58</th>
      <th>x59</th>
      <th>x60</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.376665</td>
      <td>-4.596435</td>
      <td>-4.095756</td>
      <td>13.497687</td>
      <td>-0.118830</td>
      <td>-20.669883</td>
      <td>0.000732</td>
      <td>-0.061114</td>
      <td>-0.059966</td>
      <td>-0.038189</td>
      <td>...</td>
      <td>11.295155</td>
      <td>29.984624</td>
      <td>10.091721</td>
      <td>-4.936434</td>
      <td>-24.590146</td>
      <td>18.515436</td>
      <td>3.473400</td>
      <td>0.033444</td>
      <td>0.953219</td>
      <td>0.006076</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.475720</td>
      <td>-4.542502</td>
      <td>-4.018359</td>
      <td>16.230659</td>
      <td>-0.128733</td>
      <td>-18.758079</td>
      <td>0.000732</td>
      <td>-0.061114</td>
      <td>-0.059966</td>
      <td>-0.038189</td>
      <td>...</td>
      <td>11.290761</td>
      <td>29.984624</td>
      <td>10.095871</td>
      <td>-4.937179</td>
      <td>-32.413266</td>
      <td>22.760065</td>
      <td>2.682933</td>
      <td>0.033536</td>
      <td>1.090502</td>
      <td>0.006083</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.363848</td>
      <td>-4.681394</td>
      <td>-4.353147</td>
      <td>14.127997</td>
      <td>-0.138636</td>
      <td>-17.836632</td>
      <td>0.010803</td>
      <td>-0.061114</td>
      <td>-0.030057</td>
      <td>-0.018352</td>
      <td>...</td>
      <td>11.286366</td>
      <td>29.984624</td>
      <td>10.100265</td>
      <td>-4.937924</td>
      <td>-34.183774</td>
      <td>27.004663</td>
      <td>3.537487</td>
      <td>0.033629</td>
      <td>1.840540</td>
      <td>0.006090</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.301590</td>
      <td>-4.758934</td>
      <td>-4.023612</td>
      <td>13.161566</td>
      <td>-0.148142</td>
      <td>-18.517601</td>
      <td>0.002075</td>
      <td>-0.061114</td>
      <td>-0.019986</td>
      <td>-0.008280</td>
      <td>...</td>
      <td>11.281972</td>
      <td>29.984624</td>
      <td>10.104660</td>
      <td>-4.938669</td>
      <td>-35.954281</td>
      <td>21.672449</td>
      <td>3.986095</td>
      <td>0.033721</td>
      <td>2.554880</td>
      <td>0.006097</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.265578</td>
      <td>-4.749928</td>
      <td>-4.333150</td>
      <td>15.267340</td>
      <td>-0.155314</td>
      <td>-17.505913</td>
      <td>0.000732</td>
      <td>-0.061114</td>
      <td>-0.030057</td>
      <td>-0.008280</td>
      <td>...</td>
      <td>11.277577</td>
      <td>29.984624</td>
      <td>10.109054</td>
      <td>-4.939414</td>
      <td>-37.724789</td>
      <td>21.907251</td>
      <td>3.601573</td>
      <td>0.033777</td>
      <td>1.410494</td>
      <td>0.006105</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>18393</th>
      <td>-0.877441</td>
      <td>0.786430</td>
      <td>0.406426</td>
      <td>135.301215</td>
      <td>0.112295</td>
      <td>26.300392</td>
      <td>-0.159185</td>
      <td>0.058823</td>
      <td>-0.080108</td>
      <td>-0.038189</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.682413</td>
      <td>6.944644</td>
      <td>-37.795661</td>
      <td>-0.860218</td>
      <td>0.010220</td>
      <td>0.895685</td>
      <td>-0.011242</td>
    </tr>
    <tr>
      <th>18394</th>
      <td>-0.843988</td>
      <td>0.633086</td>
      <td>0.561918</td>
      <td>133.228949</td>
      <td>0.141332</td>
      <td>25.678597</td>
      <td>-0.159185</td>
      <td>0.058823</td>
      <td>-0.080108</td>
      <td>-0.038189</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.683338</td>
      <td>0.507755</td>
      <td>-39.357199</td>
      <td>-0.915698</td>
      <td>0.010620</td>
      <td>0.175348</td>
      <td>-0.011235</td>
    </tr>
    <tr>
      <th>18395</th>
      <td>-0.826547</td>
      <td>0.450126</td>
      <td>0.334582</td>
      <td>134.977973</td>
      <td>0.170370</td>
      <td>25.056801</td>
      <td>-0.159185</td>
      <td>0.048752</td>
      <td>-0.080108</td>
      <td>-0.038189</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.684263</td>
      <td>2.809146</td>
      <td>-39.357199</td>
      <td>-1.409596</td>
      <td>0.013323</td>
      <td>0.621020</td>
      <td>-0.011228</td>
    </tr>
    <tr>
      <th>18396</th>
      <td>-0.822843</td>
      <td>0.419383</td>
      <td>0.387263</td>
      <td>135.658942</td>
      <td>0.199422</td>
      <td>24.435005</td>
      <td>-0.159185</td>
      <td>0.048752</td>
      <td>-0.080108</td>
      <td>-0.038189</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.685189</td>
      <td>2.164859</td>
      <td>-39.357199</td>
      <td>-0.860218</td>
      <td>0.012888</td>
      <td>1.390902</td>
      <td>-0.011221</td>
    </tr>
    <tr>
      <th>18397</th>
      <td>-0.840981</td>
      <td>0.582710</td>
      <td>0.593416</td>
      <td>136.339880</td>
      <td>0.228460</td>
      <td>24.712960</td>
      <td>-0.159185</td>
      <td>0.048752</td>
      <td>-0.070037</td>
      <td>-0.038189</td>
      <td>...</td>
      <td>-1.917980</td>
      <td>29.984624</td>
      <td>-0.773514</td>
      <td>2.686114</td>
      <td>1.416690</td>
      <td>-39.357199</td>
      <td>-0.732044</td>
      <td>0.012453</td>
      <td>0.418993</td>
      <td>-0.011214</td>
    </tr>
  </tbody>
</table>
<p>18398 rows × 59 columns</p>
</div>



# Splitting data into train and test


```python
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold, cross_val_score
```


```python
x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.5)
```


```python
k_folds = KFold(n_splits = 5)
```

# Apply the Multiple Linear Regression model-with all features


```python
model1 = LinearRegression()

# Fitting linear regression model on train data
model1.fit(x_train,y_train)
```




<style>#sk-container-id-1 {color: black;background-color: white;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LinearRegression()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">LinearRegression</label><div class="sk-toggleable__content"><pre>LinearRegression()</pre></div></div></div></div></div>




```python
# Predict y using linear regression
y_pred = model1.predict(x_test)
y_pred
```




    array([ 0.00427942, -0.01577404,  0.02323945, ...,  0.01551884,
           -0.01289782,  0.02045069])



Evaluation matrics for checking performance


```python
from sklearn.metrics import mean_absolute_error,mean_squared_error
 
mae = mean_absolute_error(y_true=y_test,y_pred=y_pred)
#squared True returns MSE value, False returns RMSE value.
mse = mean_squared_error(y_true=y_test,y_pred=y_pred) #default=True
rmse = mean_squared_error(y_true=y_test,y_pred=y_pred,squared=False)
 
print("MAE:",mae)
print("MSE:",mse)
print("RMSE:",rmse)
```

    MAE: 0.02237195858516822
    MSE: 0.006133716578724465
    RMSE: 0.0783180475926492
    


```python
print (model1.score(x_train,y_train))
```

    0.11981823356318255
    

cross validating the model using k fold


```python
scores1 = cross_val_score(model1, x, y, cv = k_folds)
```


```python
print("Cross Validation Scores: ", scores1)
print("Average CV Score: ", scores1.mean())
print("Number of CV Scores used in Average: ", len(scores1))
```

    Cross Validation Scores:  [ -0.20832754   0.05357875  -0.4564761  -11.61509113  -0.4628059 ]
    Average CV Score:  -2.537824382234923
    Number of CV Scores used in Average:  5
    


```python
print("%0.2f accuracy with a standard deviation of %0.2f" % (scores1.mean(), scores1.std()))
```

    -2.54 accuracy with a standard deviation of 4.54
    

# feature selection


```python
# feature selection
def select_features(x_train, y_train, x_test):
 # configure to select all features
 fs = SelectKBest(score_func=f_regression, k='all')
 # learn relationship from training data
 fs.fit(x_train, y_train)
 # transform train input data
 x_train_fs = fs.transform(x_train)
 # transform test input data
 x_test_fs = fs.transform(x_test)
 return x_train_fs, x_test_fs, fs
 
# feature selection
x_train_fs, x_test_fs, fs = select_features(x_train, y_train, x_test)

# what are scores for the features
for i in range(len(fs.scores_)):
 print('Feature %d: %f' % (i, fs.scores_[i]))

# plot the scores
plt.bar([i for i in range(len(fs.scores_))], fs.scores_)
plt.show()
```

    Feature 0: 3.369835
    Feature 1: 80.649394
    Feature 2: 148.765763
    Feature 3: 8.957422
    Feature 4: 1.335717
    Feature 5: 4.559385
    Feature 6: 2.360687
    Feature 7: 0.030429
    Feature 8: 1.482111
    Feature 9: 0.249410
    Feature 10: 9.819220
    Feature 11: 0.074060
    Feature 12: 3.446576
    Feature 13: 0.759929
    Feature 14: 10.273402
    Feature 15: 0.021775
    Feature 16: 20.449152
    Feature 17: 24.963434
    Feature 18: 204.669329
    Feature 19: 8.591854
    Feature 20: 0.259206
    Feature 21: 3.088849
    Feature 22: 2.539660
    Feature 23: 0.253938
    Feature 24: 0.625688
    Feature 25: 6.113399
    Feature 26: 1.632729
    Feature 27: 0.038441
    Feature 28: 19.166614
    Feature 29: 0.009598
    Feature 30: 0.027577
    Feature 31: 0.611039
    Feature 32: 0.247164
    Feature 33: 5.365200
    Feature 34: 6.395554
    Feature 35: 1.537221
    Feature 36: 1.319360
    Feature 37: 0.136558
    Feature 38: 0.236390
    Feature 39: 0.593204
    Feature 40: 0.688807
    Feature 41: 8.222734
    Feature 42: 1.121199
    Feature 43: 3.902580
    Feature 44: 0.387560
    Feature 45: 7.567046
    Feature 46: 0.519344
    Feature 47: 1.262924
    Feature 48: 2.770230
    Feature 49: 6.444286
    Feature 50: 0.639625
    Feature 51: 8.579400
    Feature 52: 18.802554
    Feature 53: 2.810344
    Feature 54: 4.893427
    Feature 55: 2.112001
    Feature 56: 0.003992
    Feature 57: 0.594496
    Feature 58: 2.543373
    


    
![png](output_44_1.png)
    


We can see that 10-15 features are of more importance than others

# Model Built Using selected Features
We can use the correlation method to score the features and select the 10 most relevant ones.


```python
# feature selection defination
def select_features(x_train, y_train, x_test):
 # configure to select a subset of features
 fs = SelectKBest(score_func=f_regression, k=10)
 # learn relationship from training data
 fs.fit(x_train, y_train)
 # transform train input data
 x_train_fs = fs.transform(x_train)
 # transform test input data
 x_test_fs = fs.transform(x_test)
 return x_train_fs, x_test_fs, fs
```


```python
# feature selection
x_train_fs, x_test_fs, fs = select_features(x_train, y_train, x_test)
# fit the model
model2 = LinearRegression()
model2.fit(x_train_fs, y_train)
ypred = model2.predict(x_train_fs)
ypred
```




    array([ 0.04066111, -0.00054503, -0.00527663, ...,  0.01598958,
           -0.00532146, -0.02197431])




```python
# evaluation matrix
from sklearn.metrics import mean_absolute_error,mean_squared_error
 
mae = mean_absolute_error(y_true=y_test,y_pred=y_pred)
#squared True returns MSE value, False returns RMSE value.
mse = mean_squared_error(y_true=y_test,y_pred=ypred) #default=True
rmse = mean_squared_error(y_true=y_test,y_pred=ypred,squared=False)
 
print("MAE:",mae)
print("MSE:",mse)
print("RMSE:",rmse)
```

    MAE: 0.02237195858516822
    MSE: 0.007210929940886443
    RMSE: 0.08491719461267219
    


```python
print (model2.score(x_test_fs,y_test))
```

    0.06008472920677321
    

cross validating the model using k fold


```python
scores2 = cross_val_score(model2, x, y, cv = k_folds)
```


```python
print("Cross Validation Scores: ", scores2)
print("Average CV Score: ", scores2.mean())
print("Number of CV Scores used in Average: ", len(scores2))
```

    Cross Validation Scores:  [ -0.20832754   0.05357875  -0.4564761  -11.61509113  -0.4628059 ]
    Average CV Score:  -2.537824382234923
    Number of CV Scores used in Average:  5
    


```python
print("%0.2f accuracy with a standard deviation of %0.2f" % (scores2.mean(), scores2.std()))
```

    -2.54 accuracy with a standard deviation of 4.54
    

# Using gradient boosting technique for model building


```python
from sklearn.ensemble import GradientBoostingRegressor
```


```python
modelGBR = GradientBoostingRegressor(random_state=0).fit(x_train, y_train)
```


```python
modelGBR.score(x_train, y_train)
```




    0.832262279636108




```python
modelGBR.score(x_test, y_test)
```




    0.46662027166061415




```python
YPRED =modelGBR.predict(x_train)
YPRED
```




    array([-6.90167425e-05,  3.94753655e-04,  4.88813853e-04, ...,
            3.70961159e-04, -3.96309584e-04,  5.45172177e-05])




```python
from sklearn.metrics import mean_absolute_error,mean_squared_error
 
mae = mean_absolute_error(y_true=y_test,y_pred=YPRED)
#squared True returns MSE value, False returns RMSE value.
mse = mean_squared_error(y_true=y_test,y_pred=YPRED) #default=True
rmse = mean_squared_error(y_true=y_test,y_pred=YPRED,squared=False)
 
print("MAE:",mae)
print("MSE:",mse)
print("RMSE:",rmse)
```

    MAE: 0.01331725739710279
    MSE: 0.011401636230150555
    RMSE: 0.10677844459510803
    

cross validating the model using k fold


```python
scores3 = cross_val_score(modelGBR, x, y, cv = k_folds)
```


```python
print("Cross Validation Scores: ", scores3)
print("Average CV Score: ", scores3.mean())
print("Number of CV Scores used in Average: ", len(scores3))
```

    Cross Validation Scores:  [-0.84026641  0.05720382  0.47844399 -0.31958255 -0.69145519]
    Average CV Score:  -0.26313126938538456
    Number of CV Scores used in Average:  5
    


```python
print("%0.2f accuracy with a standard deviation of %0.2f" % (scores3.mean(), scores3.std()))
```

    -0.26 accuracy with a standard deviation of 0.48
    

We can see that GRADIENT BOOSTING TECHNIQUE is the best method to build a model on this data. 

# Hyperparameter tuning using gardient boosting regressor


```python
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import GradientBoostingRegressor
```


```python
GBR = GradientBoostingRegressor()
```


```python
#Let us set the parameter
parameters = {'learning_rate': [0.01,0.02,0.03,0.04],
                  'subsample'    : [0.9, 0.5, 0.2, 0.1],
                  'n_estimators' : [100,500,1000, 1500],
                  'max_depth'    : [4,6,8,10]
                 }
```


```python
grid_GBR = GridSearchCV(estimator=GBR, param_grid = parameters, cv = 2, n_jobs=-1)
grid_GBR.fit(x_train, y_train)
```


```python
print(" Results from Grid Search " )
    print("\n The best estimator across ALL searched params:\n",grid_GBR.best_estimator_)
    print("\n The best score across ALL searched params:\n",grid_GBR.best_score_)
    print("\n The best parameters across ALL searched params:\n",grid_GBR.best_params_)
```

# Tune the Number of Selected Features using a grid search, 
where the k argument to the SelectKBest class can be tuned.


```python
from sklearn.datasets import make_regression
from sklearn.model_selection import RepeatedKFold
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV
```


```python
# define the evaluation method
cv = RepeatedKFold(n_splits=10, n_repeats=3, random_state=1)
# define the pipeline to evaluate
model = LinearRegression()
fs = SelectKBest(score_func=mutual_info_regression)
pipeline = Pipeline(steps=[('sel',fs), ('lr', model)])
# define the grid
grid = dict()
grid['sel__k'] = [i for i in range(x.shape[1]-20, x.shape[1]+1)]
# define the grid search
search = GridSearchCV(pipeline, grid, scoring='neg_mean_squared_error', n_jobs=-1, cv=cv)
# perform the search
results = search.fit(x, y)
# summarize best
print('Best MAE: %.3f' % results.best_score_)
print('Best Config: %s' % results.best_params_)
# summarize all
means = results.cv_results_['mean_test_score']
params = results.cv_results_['params']
for mean, param in zip(means, params):
    print(">%.3f with: %r" % (mean, param))
```


```python

```


```python

```
